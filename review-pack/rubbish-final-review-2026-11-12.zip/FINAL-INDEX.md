# Rubbish 全站人工审读最终索引（2026-11-12）

## 最终口径

| 指标 | 数值 |
|---|---|
| 全站稿件 | 274 |
| 已人工审读 | 274（100%） |
| 论文轨 | 228 |
| 副刊轨 | 46（作者随笔 35 + 编辑部页面 11） |
| Q1 一区 | 43 |
| Q2 二区 | 149 |
| Q3 三区 | 34 |
| Q4 四区 | 2 |
| 已计分 | 228 |
| 随笔不评级 | 46 |
| 台账/清单 | 274 条，与库内 id 一一对应 |

## 三轮复核结论

1. 第一轮：逐篇通读、五维打分，覆盖全站。
2. 第二轮：高分稿复核 + 剩余 Q2 收口，抓出 11 篇“自述随笔却按论文计分”的稿子，全部转 `essay`。
3. 第三轮：274 篇按五维原始分独立重算；211 篇加总一致，11 篇舍入差，5 篇硬冲突，158 因实质虚高从 82.4 Q1 降为 77.4 Q2；205 因执行 68 从 82.5 Q1 降为 79.5 Q2。

## 最后的实质修正

- 158：82.4 Q1 → 77.4 Q2（表 1 数字自相矛盾，维度独立加权只有 77.4）。
- 135、264、111、105、176、142、112：由论文转随笔，清空分数。
- 31、53、60、71：第 13 批已由论文转随笔。
- 100、102：补评 Q2。
- 298：清除投稿模板残留并重导 PDF。
- 130、143、152：库外历史草稿，移出主台账存档。
- 154、157、195、196、204：维度分按判词重标，总分/分区不变。

## 验收

- `/papers`、`/fun` 列表页 200。
- 158、135、264、111、105、176、142、112、305、315 详情页 `/catalog/{id}` 全部 200。
- 同批 10 篇 PDF 导出全部 200。
- 228 篇论文五维分与总分全部精确对上，无尾差。

## 文件导航

- 总报告：`manual-review-batch-14.md`、`15.md`、`16-third-pass.md`、`17-essays.md`、`18-q1-compensation.md`、`19-strict-closeout.md`
- 逐篇表：`batch-14-audit.csv`、`batch-15-audit.csv`、`batch-16-third-pass-audit.csv`、`batch-17-essay-audit.csv`、`batch-18-q1-compensation-audit.csv`、`batch-19-303-pages.csv`、`batch-19-essay-structure.csv`
- 台账：`manual-review-ledger.csv`、`manual-review-score-diff.csv`、`manual-review-manifest.csv`
- 图表：`batch-14-audit-90.png`、`batch-15-audit-109.png`、`batch-16-third-pass.png`、`batch-17-essays.png`、`site-overview-2026-11-12-b16.png`
- 历史批次：`manual-review-batch-01.md`–`19`、`editorial-completions-*.md`
- 库外存档：`manual-review-ledger-orphans.csv`

## 严格验收结论

- 303 的 59 页已逐页验收：0 空白、0 溢出、0 断表，接受其 59 页篇幅。
- 35 篇作者随笔已逐篇查字数、段落、标题与结尾：35/35 完整。
- 157 尾差已清零，228 篇论文五维与总分全部精确对上。
- Q1 补偿稿已终审：10 篇保留、205 降 Q2；不再挂“下一轮复核”。
- 46 条 essay 中 11 个是编辑部页面，不按“短随笔”扩写。
